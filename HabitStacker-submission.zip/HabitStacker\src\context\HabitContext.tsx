import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { HabitStack, DailyLog, AllStreaks, AppSettings } from '../types';
import {
  loadStacks, saveStacks,
  loadDailyLog, saveDailyLog,
  loadStreaks, saveStreaks,
  loadSettings, saveSettings,
  clearAllData,
} from '../storage/storage';
import { todayString } from '../utils/dateUtils';
import { computeUpdatedStreak } from '../utils/streakUtils';
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

interface HabitState {
  stacks: HabitStack[];
  todayLog: DailyLog;
  streaks: AllStreaks;
  settings: AppSettings;
  isLoaded: boolean;
}

type Action =
  | { type: 'LOAD'; payload: Omit<HabitState, 'isLoaded'> }
  | { type: 'SAVE_STACKS'; payload: HabitStack[] }
  | { type: 'UPDATE_TODAY_LOG'; payload: DailyLog }
  | { type: 'UPDATE_STREAKS'; payload: AllStreaks }
  | { type: 'UPDATE_SETTINGS'; payload: AppSettings }
  | { type: 'RESET' };

function reducer(state: HabitState, action: Action): HabitState {
  switch (action.type) {
    case 'LOAD':
      return { ...state, ...action.payload, isLoaded: true };
    case 'SAVE_STACKS':
      return { ...state, stacks: action.payload };
    case 'UPDATE_TODAY_LOG':
      return { ...state, todayLog: action.payload };
    case 'UPDATE_STREAKS':
      return { ...state, streaks: action.payload };
    case 'UPDATE_SETTINGS':
      return { ...state, settings: action.payload };
    case 'RESET':
      return { ...initialState, isLoaded: true };
    default:
      return state;
  }
}

const initialState: HabitState = {
  stacks: [],
  todayLog: {},
  streaks: {},
  settings: { notificationsEnabled: true },
  isLoaded: false,
};

interface HabitContextValue extends HabitState {
  addStack: (stack: HabitStack) => Promise<void>;
  updateStack: (stack: HabitStack) => Promise<void>;
  deleteStack: (stackId: string) => Promise<void>;
  toggleHabit: (stackId: string, habitId: string) => Promise<void>;
  updateSettings: (settings: AppSettings) => Promise<void>;
  resetAllData: () => Promise<void>;
  completionForStack: (stackId: string) => { done: number; total: number; isComplete: boolean };
}

const HabitContext = createContext<HabitContextValue | null>(null);

async function requestNotificationPermission(): Promise<boolean> {
  if (Platform.OS === 'web') return false;
  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

async function scheduleStackNotification(stack: HabitStack): Promise<void> {
  if (!stack.reminderTime) return;
  const [hour, minute] = stack.reminderTime.split(':').map(Number);

  // Cancel existing notifications for this stack
  await cancelStackNotification(stack.id);

  await Notifications.scheduleNotificationAsync({
    identifier: `stack_${stack.id}`,
    content: {
      title: `Time for ${stack.name}!`,
      body: `You have ${stack.habits.length} habit${stack.habits.length !== 1 ? 's' : ''} to complete.`,
      sound: true,
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.DAILY,
      hour,
      minute,
    },
  });
}

async function cancelStackNotification(stackId: string): Promise<void> {
  await Notifications.cancelScheduledNotificationAsync(`stack_${stackId}`);
}

export function HabitProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  // Load all data on mount
  useEffect(() => {
    async function init() {
      const [stacks, todayLog, streaks, settings] = await Promise.all([
        loadStacks(),
        loadDailyLog(todayString()),
        loadStreaks(),
        loadSettings(),
      ]);
      dispatch({ type: 'LOAD', payload: { stacks, todayLog, streaks, settings } });

      // Set up notification handler
      Notifications.setNotificationHandler({
        handleNotification: async () => ({
          shouldShowAlert: true,
          shouldPlaySound: true,
          shouldSetBadge: false,
          shouldShowBanner: true,
          shouldShowList: true,
        }),
      });
    }
    init();
  }, []);

  const addStack = useCallback(async (stack: HabitStack) => {
    const updated = [...state.stacks, stack];
    await saveStacks(updated);
    dispatch({ type: 'SAVE_STACKS', payload: updated });

    if (state.settings.notificationsEnabled && stack.reminderTime) {
      const granted = await requestNotificationPermission();
      if (granted) await scheduleStackNotification(stack);
    }
  }, [state.stacks, state.settings]);

  const updateStack = useCallback(async (stack: HabitStack) => {
    const updated = state.stacks.map(s => s.id === stack.id ? stack : s);
    await saveStacks(updated);
    dispatch({ type: 'SAVE_STACKS', payload: updated });

    if (state.settings.notificationsEnabled && stack.reminderTime) {
      const granted = await requestNotificationPermission();
      if (granted) await scheduleStackNotification(stack);
    } else {
      await cancelStackNotification(stack.id);
    }
  }, [state.stacks, state.settings]);

  const deleteStack = useCallback(async (stackId: string) => {
    const updated = state.stacks.filter(s => s.id !== stackId);
    await saveStacks(updated);
    dispatch({ type: 'SAVE_STACKS', payload: updated });
    await cancelStackNotification(stackId);

    // Clean streaks
    const updatedStreaks = { ...state.streaks };
    delete updatedStreaks[stackId];
    await saveStreaks(updatedStreaks);
    dispatch({ type: 'UPDATE_STREAKS', payload: updatedStreaks });
  }, [state.stacks, state.streaks]);

  const toggleHabit = useCallback(async (stackId: string, habitId: string) => {
    const today = todayString();
    const stack = state.stacks.find(s => s.id === stackId);
    if (!stack) return;

    const current = state.todayLog[stackId] ?? { completed: false, habitsDone: [] };
    let habitsDone: string[];

    if (current.habitsDone.includes(habitId)) {
      habitsDone = current.habitsDone.filter(id => id !== habitId);
    } else {
      habitsDone = [...current.habitsDone, habitId];
    }

    const isComplete = habitsDone.length === stack.habits.length;
    const updatedEntry = {
      completed: isComplete,
      habitsDone,
      completedAt: isComplete ? new Date().toISOString() : current.completedAt,
    };

    const updatedLog = { ...state.todayLog, [stackId]: updatedEntry };
    await saveDailyLog(today, updatedLog);
    dispatch({ type: 'UPDATE_TODAY_LOG', payload: updatedLog });

    // Update streak
    const updatedStreak = computeUpdatedStreak(state.streaks[stackId], isComplete);
    const updatedStreaks = { ...state.streaks, [stackId]: updatedStreak };
    await saveStreaks(updatedStreaks);
    dispatch({ type: 'UPDATE_STREAKS', payload: updatedStreaks });
  }, [state.stacks, state.todayLog, state.streaks]);

  const updateSettings = useCallback(async (settings: AppSettings) => {
    await saveSettings(settings);
    dispatch({ type: 'UPDATE_SETTINGS', payload: settings });

    if (!settings.notificationsEnabled) {
      await Notifications.cancelAllScheduledNotificationsAsync();
    } else {
      const granted = await requestNotificationPermission();
      if (granted) {
        for (const stack of state.stacks) {
          if (stack.reminderTime) await scheduleStackNotification(stack);
        }
      }
    }
  }, [state.stacks]);

  const resetAllData = useCallback(async () => {
    await clearAllData();
    await Notifications.cancelAllScheduledNotificationsAsync();
    dispatch({ type: 'RESET' });
  }, []);

  const completionForStack = useCallback((stackId: string) => {
    const stack = state.stacks.find(s => s.id === stackId);
    if (!stack) return { done: 0, total: 0, isComplete: false };
    const entry = state.todayLog[stackId];
    const done = entry?.habitsDone?.length ?? 0;
    const total = stack.habits.length;
    return { done, total, isComplete: entry?.completed ?? false };
  }, [state.stacks, state.todayLog]);

  return (
    <HabitContext.Provider value={{
      ...state,
      addStack,
      updateStack,
      deleteStack,
      toggleHabit,
      updateSettings,
      resetAllData,
      completionForStack,
    }}>
      {children}
    </HabitContext.Provider>
  );
}

export function useHabits(): HabitContextValue {
  const ctx = useContext(HabitContext);
  if (!ctx) throw new Error('useHabits must be used inside HabitProvider');
  return ctx;
}
