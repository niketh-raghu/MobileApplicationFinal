import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { Colors } from '../theme';
import HomeScreen from '../screens/HomeScreen';
import WeeklyStatsScreen from '../screens/WeeklyStatsScreen';
import SettingsScreen from '../screens/SettingsScreen';
import StackBuilderScreen from '../screens/StackBuilderScreen';
import StackDetailScreen from '../screens/StackDetailScreen';
import HowToUseScreen from '../screens/HowToUseScreen';

export type RootStackParamList = {
  MainTabs: undefined;
  StackBuilder: { stackId?: string };
  StackDetail: { stackId: string };
  HowToUse: undefined;
};

export type TabParamList = {
  Today: undefined;
  Stacks: undefined;
  Stats: undefined;
  Alerts: undefined;
};

const Tab = createBottomTabNavigator<TabParamList>();
const Stack = createStackNavigator<RootStackParamList>();

function TabIcon({ name, focused }: { name: string; focused: boolean }) {
  const icons: Record<string, string> = {
    Today: '🏠',
    Stacks: '🔗',
    Stats: '📊',
    Alerts: '🔔',
  };
  return (
    <Text style={{ fontSize: 20, opacity: focused ? 1 : 0.45 }}>{icons[name]}</Text>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: Colors.primary,
        tabBarInactiveTintColor: Colors.textMuted,
        tabBarLabelStyle: styles.tabLabel,
        tabBarIcon: ({ focused }) => <TabIcon name={route.name} focused={focused} />,
      })}
    >
      <Tab.Screen name="Today" component={HomeScreen} />
      <Tab.Screen name="Stacks" component={StacksTab} />
      <Tab.Screen name="Stats" component={WeeklyStatsScreen} />
      <Tab.Screen name="Alerts" component={SettingsScreen} />
    </Tab.Navigator>
  );
}

// Stacks tab shows HomeScreen in list-of-stacks mode
function StacksTab() {
  return <HomeScreen stacksMode />;
}

function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="MainTabs" component={MainTabs} />
        <Stack.Screen name="StackBuilder" component={StackBuilderScreen} />
        <Stack.Screen name="StackDetail" component={StackDetailScreen} />
        <Stack.Screen name="HowToUse" component={HowToUseScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: Colors.tabBar,
    borderTopColor: Colors.tabBarBorder,
    borderTopWidth: 1,
    paddingTop: 4,
    height: 72,
  },
  tabLabel: {
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 0.3,
    marginBottom: 4,
  },
});

export default AppNavigator;
