import React, { useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  StatusBar, SafeAreaView, Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useHabits } from '../context/HabitContext';
import { Colors, Spacing, Radius, Typography } from '../theme';
import { greetingForHour, shortDate, formatTime } from '../utils/dateUtils';
import { RootStackParamList } from '../navigation/AppNavigator';
import ProgressBar from '../components/ProgressBar';
import StreakBadge from '../components/StreakBadge';

type Nav = StackNavigationProp<RootStackParamList>;

interface Props {
  stacksMode?: boolean;
}

const CATEGORY_COLORS: Record<string, string> = {
  Health: Colors.tagHealth,
  Fitness: Colors.tagFitness,
  Focus: Colors.tagFocus,
  Skills: Colors.tagSkills,
};

export default function HomeScreen({ stacksMode = false }: Props) {
  const nav = useNavigation<Nav>();
  const { stacks, todayLog, streaks, toggleHabit, completionForStack, deleteStack } = useHabits();

  const totalDone = stacks.filter(s => completionForStack(s.id).isComplete).length;
  const totalStacks = stacks.length;
  const bestStreak = Math.max(0, ...Object.values(streaks).map(s => s.current));

  const handleToggleHabit = useCallback((stackId: string, habitId: string) => {
    toggleHabit(stackId, habitId);
  }, [toggleHabit]);

  const handleDeleteStack = useCallback((stackId: string, name: string) => {
    Alert.alert(
      'Delete Stack',
      `Remove "${name}"? This cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => deleteStack(stackId) },
      ]
    );
  }, [deleteStack]);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.background} />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>
              {stacksMode ? 'My Stacks' : `${greetingForHour()} 👋`}
            </Text>
            {!stacksMode && (
              <Text style={styles.dateLabel}>{shortDate()} · {totalDone} of {totalStacks} done</Text>
            )}
          </View>
          <TouchableOpacity
            style={styles.addBtn}
            onPress={() => nav.navigate('StackBuilder', {})}
            activeOpacity={0.8}
          >
            <Text style={styles.addBtnText}>+</Text>
          </TouchableOpacity>
        </View>

        {/* Streak Banner */}
        {!stacksMode && bestStreak > 0 && (
          <View style={styles.streakBanner}>
            <Text style={styles.streakEmoji}>{bestStreak >= 7 ? '🔥' : '⚡'}</Text>
            <View>
              <Text style={styles.streakTitle}>{bestStreak}-Day Streak!</Text>
              <Text style={styles.streakSub}>Keep it going — {bestStreak >= 7 ? 2 : 7 - bestStreak} more to hit 7 days</Text>
            </View>
          </View>
        )}

        {/* Empty State */}
        {stacks.length === 0 && (
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>🔗</Text>
            <Text style={styles.emptyTitle}>No stacks yet</Text>
            <Text style={styles.emptySub}>Create your first habit stack to get started.</Text>
            <TouchableOpacity
              style={styles.emptyBtn}
              onPress={() => nav.navigate('StackBuilder', {})}
              activeOpacity={0.8}
            >
              <Text style={styles.emptyBtnText}>Create Stack</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Stack Cards */}
        <Text style={styles.sectionLabel}>
          {stacksMode ? 'ALL STACKS' : "TODAY'S HABITS"}
        </Text>

        {stacks.map(stack => {
          const { done, total, isComplete } = completionForStack(stack.id);
          const streak = streaks[stack.id] ?? { current: 0, best: 0, lastCompletedDate: null };
          const log = todayLog[stack.id];
          const habitsDone = log?.habitsDone ?? [];

          return (
            <View key={stack.id} style={[styles.card, isComplete && styles.cardComplete]}>
              {/* Card Header */}
              <View style={styles.cardHeader}>
                <View style={styles.cardTitleRow}>
                  <Text style={styles.cardTitle}>{stack.name}</Text>
                  {isComplete && <Text style={styles.doneTag}>✓ DONE</Text>}
                </View>
                <View style={styles.cardMeta}>
                  <StreakBadge streak={streak.current} size="sm" />
                  <TouchableOpacity
                    onPress={() => nav.navigate('StackBuilder', { stackId: stack.id })}
                    style={styles.editBtn}
                  >
                    <Text style={styles.editBtnText}>Edit</Text>
                  </TouchableOpacity>
                  {stacksMode && (
                    <TouchableOpacity
                      onPress={() => handleDeleteStack(stack.id, stack.name)}
                      style={styles.deleteBtn}
                    >
                      <Text style={styles.deleteBtnText}>✕</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>

              {/* Progress */}
              <View style={styles.progressRow}>
                <ProgressBar
                  progress={total > 0 ? done / total : 0}
                  height={5}
                  color={isComplete ? Colors.primary : Colors.accent}
                />
                <Text style={styles.progressLabel}>{done}/{total}</Text>
              </View>

              {/* Habit List */}
              {stack.habits.map((habit, idx) => {
                const isDone = habitsDone.includes(habit.id);
                const catColor = CATEGORY_COLORS[habit.category] ?? Colors.primary;

                return (
                  <TouchableOpacity
                    key={habit.id}
                    style={[styles.habitRow, isDone && styles.habitRowDone]}
                    onPress={() => !stacksMode && handleToggleHabit(stack.id, habit.id)}
                    activeOpacity={stacksMode ? 1 : 0.7}
                  >
                    <View style={[styles.habitIdx, { backgroundColor: catColor + '20' }]}>
                      <Text style={{ fontSize: 12, color: catColor }}>{idx + 1}</Text>
                    </View>
                    <Text style={styles.habitIcon}>{habit.icon}</Text>
                    <View style={styles.habitInfo}>
                      <Text style={[styles.habitName, isDone && styles.habitNameDone]}>
                        {habit.name}
                      </Text>
                      <Text style={styles.habitMeta}>
                        {habit.category}
                        {habit.durationMinutes ? ` · ${habit.durationMinutes} min` : ''}
                        {stack.reminderTime ? ` · ${formatTime(stack.reminderTime)}` : ''}
                      </Text>
                    </View>
                    {!stacksMode && (
                      <View style={[styles.checkbox, isDone && styles.checkboxDone]}>
                        {isDone && <Text style={styles.checkmark}>✓</Text>}
                      </View>
                    )}
                  </TouchableOpacity>
                );
              })}

              {/* Stack reminder */}
              {stack.reminderTime && (
                <View style={styles.reminderRow}>
                  <Text style={styles.reminderText}>🔔 Reminder: {formatTime(stack.reminderTime)}</Text>
                </View>
              )}
            </View>
          );
        })}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  scroll: { flex: 1 },
  content: { padding: Spacing.md, paddingBottom: 100 },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  greeting: { ...Typography.title, color: Colors.text },
  dateLabel: { ...Typography.caption, color: Colors.textSecondary, marginTop: 2 },
  addBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addBtnText: { color: Colors.background, fontSize: 24, fontWeight: '300', lineHeight: 28 },

  streakBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.streakBanner,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.primary + '30',
  },
  streakEmoji: { fontSize: 28 },
  streakTitle: { ...Typography.subtitle, color: Colors.primary },
  streakSub: { ...Typography.caption, color: Colors.textSecondary, marginTop: 2 },

  sectionLabel: {
    ...Typography.label,
    color: Colors.textMuted,
    marginBottom: Spacing.sm,
    marginTop: Spacing.xs,
  },

  emptyState: {
    alignItems: 'center',
    paddingVertical: Spacing.xl * 2,
  },
  emptyEmoji: { fontSize: 48, marginBottom: Spacing.md },
  emptyTitle: { ...Typography.subtitle, color: Colors.text, marginBottom: Spacing.xs },
  emptySub: { ...Typography.body, color: Colors.textSecondary, textAlign: 'center', marginBottom: Spacing.lg },
  emptyBtn: {
    backgroundColor: Colors.primary,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm + 4,
    borderRadius: Radius.full,
  },
  emptyBtnText: { color: Colors.background, fontWeight: '700', fontSize: 14 },

  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  cardComplete: {
    borderColor: Colors.primary + '40',
    backgroundColor: Colors.completedBg,
  },

  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.sm,
  },
  cardTitleRow: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
  cardTitle: { ...Typography.subtitle, color: Colors.text, flex: 1 },
  doneTag: {
    fontSize: 10,
    fontWeight: '700',
    color: Colors.primary,
    backgroundColor: Colors.primary + '20',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: Radius.full,
  },
  cardMeta: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  editBtn: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: Radius.sm,
    backgroundColor: Colors.border,
  },
  editBtnText: { fontSize: 11, color: Colors.textSecondary, fontWeight: '600' },
  deleteBtn: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: Radius.sm,
    backgroundColor: Colors.danger + '20',
  },
  deleteBtnText: { fontSize: 11, color: Colors.danger, fontWeight: '700' },

  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  progressLabel: { ...Typography.caption, color: Colors.textSecondary, minWidth: 28, textAlign: 'right' },

  habitRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    gap: Spacing.sm,
  },
  habitRowDone: { opacity: 0.6 },
  habitIdx: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  habitIcon: { fontSize: 18 },
  habitInfo: { flex: 1 },
  habitName: { ...Typography.body, color: Colors.text, fontWeight: '500' },
  habitNameDone: { textDecorationLine: 'line-through', color: Colors.textSecondary },
  habitMeta: { ...Typography.caption, color: Colors.textMuted, marginTop: 1 },

  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxDone: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  checkmark: { color: Colors.background, fontSize: 13, fontWeight: '700' },

  reminderRow: {
    marginTop: Spacing.xs,
    paddingTop: Spacing.xs,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  reminderText: { ...Typography.caption, color: Colors.textMuted },
});
