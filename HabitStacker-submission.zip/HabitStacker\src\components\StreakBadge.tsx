import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors, Radius } from '../theme';

interface Props {
  streak: number;
  size?: 'sm' | 'md' | 'lg';
}

export default function StreakBadge({ streak, size = 'md' }: Props) {
  const isHot = streak >= 3;
  const sizes = { sm: 11, md: 13, lg: 16 };
  const fs = sizes[size];

  return (
    <View style={[styles.badge, { backgroundColor: isHot ? Colors.gold + '20' : Colors.surface }]}>
      <Text style={{ fontSize: fs }}>{isHot ? '🔥' : '⚡'}</Text>
      <Text style={[styles.count, { fontSize: fs, color: isHot ? Colors.gold : Colors.textSecondary }]}>
        {streak}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: Radius.full,
  },
  count: {
    fontWeight: '700',
  },
});
