# HabitStacker

> Stack habits. Build streaks. Live better.

**Team:** Niketh · Freddy · Yash  
**Course Milestone:** 2

---

## Overview

HabitStacker is a React Native mobile app (built with Expo) that helps users group daily habits into ordered routines called **stacks**, track completion **streaks**, and stay consistent with **smart daily reminders**. All data is stored locally on the device — no account or internet connection required.

---

## Features

- **Habit Stacking** — Group 2–5 habits into named stacks completed in sequence
- **Streak Tracking** — Consecutive-day streaks per stack; resets automatically on a missed day
- **Daily Reminders** — Per-stack push notifications via Expo Notifications
- **Weekly Stats** — Bar chart (Mon–Sun) with completion rate, streak, and best-habit card
- **Fully Offline** — All data lives in AsyncStorage; no backend, no login

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | React Native + Expo SDK 54 |
| Language | TypeScript |
| Navigation | React Navigation 7 (Bottom Tabs + Stack) |
| State | React Context API + useReducer |
| Persistence | AsyncStorage |
| Notifications | expo-notifications |

---

## Screens

| Screen | Tab | Description |
|---|---|---|
| **Today** | 🏠 Today | Daily habit checklist with progress bars and streak banners |
| **Stacks** | 🔗 Stacks | Manage all stacks — create, edit, delete |
| **Stack Builder** | Modal | Create/edit a stack: name, habits, frequency, reminder time |
| **Stack Detail** | Pushed | Numbered habit chain with next-step highlighting |
| **Weekly Stats** | 📊 Stats | Bar chart + 4 stat cards + best-stack highlight |
| **Alerts / Settings** | 🔔 Alerts | Reminder toggles, notification permissions, reset data |
| **How to Use** | From Alerts | In-app guide covering every feature |

---

## Prerequisites

| Tool | Version | Install |
|---|---|---|
| Node.js | 18 or higher | https://nodejs.org |
| npm | comes with Node | — |
| Expo Go (phone) | latest | App Store / Google Play |

> **No Xcode or Android Studio required** — Expo Go lets you run the app directly on your phone.

---

## Setup & Running

### 1. Install dependencies

```bash
cd HabitStacker
npm install
```

### 2. Start the development server

```bash
npx expo start --tunnel
```

> Use `--tunnel` if your phone and computer are on different networks or if the QR code gives a "could not connect" error. It will prompt you to install `@expo/ngrok` on first use — type **y** to accept.

### 3. Open on your phone

1. Install **Expo Go** from the App Store (iOS) or Google Play (Android)
2. Scan the QR code shown in the terminal
3. The app will bundle and launch on your device

### Running on an emulator (optional)

```bash
npx expo start --android   # Android emulator (requires Android Studio)
npx expo start --ios       # iOS simulator (macOS + Xcode only)
```

---

## Project Structure

```
HabitStacker/
├── App.tsx                          # Entry point
├── app.json                         # Expo config
├── src/
│   ├── types/index.ts               # TypeScript interfaces
│   ├── theme/index.ts               # Colors, Typography, Spacing
│   ├── storage/storage.ts           # AsyncStorage CRUD helpers
│   ├── utils/
│   │   ├── dateUtils.ts             # Date formatting helpers
│   │   ├── streakUtils.ts           # Streak calculation logic
│   │   └── statsUtils.ts           # Weekly stats aggregation
│   ├── context/HabitContext.tsx     # Global state (Context + useReducer)
│   ├── navigation/AppNavigator.tsx  # Navigation tree
│   ├── components/
│   │   ├── CategoryChip.tsx
│   │   ├── ProgressBar.tsx
│   │   └── StreakBadge.tsx
│   └── screens/
│       ├── HomeScreen.tsx
│       ├── StackBuilderScreen.tsx
│       ├── StackDetailScreen.tsx
│       ├── WeeklyStatsScreen.tsx
│       ├── SettingsScreen.tsx
│       └── HowToUseScreen.tsx
└── assets/                          # Icons and splash screen
```

---

## Data Model

All data is stored in AsyncStorage under these keys:

| Key | Type | Description |
|---|---|---|
| `habitstacker_stacks` | `HabitStack[]` | All habit stacks |
| `habitstacker_log_YYYY-MM-DD` | `DailyLog` | Per-day completion state |
| `habitstacker_streaks` | `AllStreaks` | Streak data per stack |
| `habitstacker_settings` | `AppSettings` | Notification toggle |

### Core Types

```typescript
interface HabitStack {
  id: string;
  name: string;
  habits: Habit[];          // 2–5 habits, ordered
  reminderTime: string | null; // "HH:MM"
  frequency: 'Daily' | 'Weekdays' | 'Weekly';
  createdAt: string;
}

interface Habit {
  id: string;
  name: string;
  icon: string;             // emoji
  category: 'Health' | 'Fitness' | 'Focus' | 'Skills';
  durationMinutes?: number;
}
```

---

## How Streaks Work

- Completing **all habits** in a stack for a given day marks it complete and increments the streak
- Missing a day resets the streak to 0 (best-ever is preserved)
- Streaks are recalculated on the next app open using date-diff logic in `src/utils/streakUtils.ts`

---

## Notification Setup

Notifications are scheduled via `expo-notifications` using a `DAILY` trigger (fires at the same time every day). The app requests permission on first reminder setup and gracefully handles denial with a prompt to open device Settings.

> Push notifications only fire on a **physical device**. They will not appear in a simulator/emulator.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "Could not connect to server" in Expo Go | Run `npx expo start --tunnel` instead |
| Running scripts is disabled (Windows) | Run `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser` in PowerShell |
| App not updating after code change | Shake the device → Reload, or press `r` in the terminal |
| Notifications not appearing | Check device notification permissions for Expo Go in Settings |

---

## Acceptance Criteria — Status

- [x] User can create a habit stack with 2–5 habits and a reminder time
- [x] Completing all habits in a stack marks it done and increments streak
- [x] Streak resets if a day is missed
- [x] Weekly stats screen shows correct completion data for the past 7 days
- [x] Notifications fire at the scheduled time
- [x] Permission denial shows a friendly fallback — app does not crash
- [x] All data persists across app restarts
