import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { HabitCategory } from '../types';
import { Colors, Radius } from '../theme';

const categoryColors: Record<HabitCategory, string> = {
  Health: Colors.tagHealth,
  Fitness: Colors.tagFitness,
  Focus: Colors.tagFocus,
  Skills: Colors.tagSkills,
};

interface Props {
  category: HabitCategory;
  selected?: boolean;
  onPress?: () => void;
}

export default function CategoryChip({ category, selected, onPress }: Props) {
  const color = categoryColors[category];
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      style={[
        styles.chip,
        { borderColor: color, backgroundColor: selected ? color + '30' : 'transparent' },
      ]}
    >
      <Text style={[styles.label, { color: selected ? color : Colors.textSecondary }]}>
        {category}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: Radius.full,
    borderWidth: 1.5,
    marginRight: 8,
  },
  label: {
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.3,
  },
});
