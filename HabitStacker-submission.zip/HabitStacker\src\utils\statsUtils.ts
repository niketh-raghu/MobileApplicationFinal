import { DailyLog, HabitStack, WeekDayStats } from '../types';
import { last7Days, dayLabel } from './dateUtils';

export function buildWeekStats(
  stacks: HabitStack[],
  logs: Record<string, DailyLog>
): WeekDayStats[] {
  const days = last7Days();
  return days.map(date => {
    const log = logs[date] ?? {};
    let completed = 0;
    let total = stacks.length;

    for (const stack of stacks) {
      if (log[stack.id]?.completed) completed++;
    }

    return { date, label: dayLabel(date), completed, total };
  });
}

export function overallCompletionRate(weekStats: WeekDayStats[]): number {
  const totalSlots = weekStats.reduce((sum, d) => sum + d.total, 0);
  const totalDone = weekStats.reduce((sum, d) => sum + d.completed, 0);
  if (totalSlots === 0) return 0;
  return Math.round((totalDone / totalSlots) * 100);
}

export function totalHabitsDoneThisWeek(weekStats: WeekDayStats[]): number {
  return weekStats.reduce((sum, d) => sum + d.completed, 0);
}
