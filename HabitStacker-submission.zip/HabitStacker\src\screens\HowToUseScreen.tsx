import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  SafeAreaView, StatusBar,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { Colors, Spacing, Radius, Typography } from '../theme';
import { RootStackParamList } from '../navigation/AppNavigator';

type Nav = StackNavigationProp<RootStackParamList>;

interface Step {
  icon: string;
  title: string;
  description: string;
  tip?: string;
}

const SECTIONS: { heading: string; color: string; steps: Step[] }[] = [
  {
    heading: 'Getting Started',
    color: Colors.primary,
    steps: [
      {
        icon: '🔗',
        title: 'What is a Habit Stack?',
        description:
          'A habit stack is a group of 2–5 habits you do back-to-back, in order — like a morning routine. Stacking habits together makes them easier to remember and stick to.',
        tip: 'Example: Meditation → Journal → Read → Cold shower',
      },
      {
        icon: '➕',
        title: 'Create Your First Stack',
        description:
          'Tap the + button on the Today or Stacks tab. Give your stack a name, pick an icon and category for each habit, set how often you do it, and optionally set a daily reminder time.',
        tip: 'A stack needs at least 2 habits. You can add up to 5.',
      },
    ],
  },
  {
    heading: 'Completing Habits',
    color: Colors.accent,
    steps: [
      {
        icon: '✅',
        title: 'Check Off Habits',
        description:
          'On the Today tab, tap the checkbox next to each habit as you complete it. Progress is saved automatically — no save button needed.',
        tip: 'Habits reset every day at midnight.',
      },
      {
        icon: '🏁',
        title: 'Finishing a Stack',
        description:
          'When you check off every habit in a stack, it\'s marked DONE with a green border. Your streak for that stack goes up by 1.',
      },
      {
        icon: '🔢',
        title: 'Habit Order Matters',
        description:
          'On the Stack Detail screen (tap a stack\'s card on the Stacks tab), habits are shown as a numbered chain. The next habit is highlighted — complete them in order for the full stacking benefit.',
      },
    ],
  },
  {
    heading: 'Streaks & Stats',
    color: Colors.gold,
    steps: [
      {
        icon: '🔥',
        title: 'Building Streaks',
        description:
          'Complete every habit in a stack for the day and your streak count goes up. Miss a day and it resets to zero. Your best-ever streak is always saved.',
        tip: 'Complete your stacks before midnight to keep your streak alive.',
      },
      {
        icon: '📊',
        title: 'Weekly Stats',
        description:
          'The Stats tab shows a bar chart of how many stacks you completed each day this week, your overall completion rate, total time, and which stack has your best streak.',
      },
    ],
  },
  {
    heading: 'Reminders & Settings',
    color: Colors.tagFitness,
    steps: [
      {
        icon: '🔔',
        title: 'Setting a Reminder',
        description:
          'When creating or editing a stack, toggle on the reminder and pick a time. You\'ll get a daily notification at that time. Each stack can have its own reminder time.',
        tip: 'Tap "Alerts" in the tab bar to see all your reminders at a glance.',
      },
      {
        icon: '⏸️',
        title: 'Pausing Reminders',
        description:
          'On the Alerts tab, toggle off "Daily Reminders" to pause all notifications. Individual stack reminders are paused too until you turn it back on.',
      },
      {
        icon: '✏️',
        title: 'Editing a Stack',
        description:
          'Tap Edit next to any stack on the Today or Stacks tab. You can rename the stack, reorder habits with the ↑↓ arrows, add new habits, or change the reminder time.',
      },
      {
        icon: '🗑️',
        title: 'Deleting a Stack',
        description:
          'On the Stacks tab, tap the ✕ button next to a stack to delete it. This also clears its streak and reminder. Today\'s completions are kept in your history.',
      },
    ],
  },
];

export default function HowToUseScreen() {
  const nav = useNavigation<Nav>();
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  function toggle(key: string) {
    setExpanded(prev => ({ ...prev, [key]: !prev[key] }));
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.background} />
      <View style={styles.topBar}>
        <TouchableOpacity
          onPress={() => nav.canGoBack() ? nav.goBack() : nav.navigate('MainTabs')}
          style={styles.backBtn}
        >
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.topTitle}>How to Use</Text>
        <View style={{ width: 60 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.hero}>Stack habits.</Text>
        <Text style={styles.heroSub}>Build streaks. Live better.</Text>
        <Text style={styles.intro}>
          HabitStacker helps you group daily habits into ordered routines called stacks, track your
          completion streaks, and stay consistent with smart reminders.
        </Text>

        {SECTIONS.map(section => (
          <View key={section.heading} style={styles.section}>
            <View style={[styles.sectionHeadingRow, { borderLeftColor: section.color }]}>
              <Text style={[styles.sectionHeading, { color: section.color }]}>
                {section.heading}
              </Text>
            </View>

            {section.steps.map((step, idx) => {
              const key = `${section.heading}-${idx}`;
              const open = expanded[key] ?? true;

              return (
                <TouchableOpacity
                  key={key}
                  style={styles.stepCard}
                  onPress={() => toggle(key)}
                  activeOpacity={0.8}
                >
                  <View style={styles.stepHeader}>
                    <View style={[styles.stepIconWrap, { backgroundColor: section.color + '20' }]}>
                      <Text style={styles.stepIcon}>{step.icon}</Text>
                    </View>
                    <Text style={styles.stepTitle}>{step.title}</Text>
                    <Text style={styles.chevron}>{open ? '▾' : '▸'}</Text>
                  </View>

                  {open && (
                    <View style={styles.stepBody}>
                      <Text style={styles.stepDesc}>{step.description}</Text>
                      {step.tip && (
                        <View style={[styles.tipBox, { borderLeftColor: section.color }]}>
                          <Text style={styles.tipLabel}>TIP</Text>
                          <Text style={styles.tipText}>{step.tip}</Text>
                        </View>
                      )}
                    </View>
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        ))}

        {/* Quick Reference */}
        <View style={styles.quickRef}>
          <Text style={styles.quickRefTitle}>Quick Reference</Text>
          {[
            ['Today tab', 'Check off habits for today'],
            ['Stacks tab', 'Create, edit, or delete stacks'],
            ['Stats tab', 'View your weekly progress chart'],
            ['Alerts tab', 'Manage reminders & settings'],
            ['+ button', 'Create a new habit stack'],
            ['Edit button', 'Modify an existing stack'],
            ['Streak 🔥', 'Days in a row you finished a stack'],
          ].map(([label, desc]) => (
            <View key={label} style={styles.quickRow}>
              <Text style={styles.quickLabel}>{label}</Text>
              <Text style={styles.quickDesc}>{desc}</Text>
            </View>
          ))}
        </View>

        <TouchableOpacity
          style={styles.doneBtn}
          onPress={() => nav.canGoBack() ? nav.goBack() : nav.navigate('MainTabs')}
        >
          <Text style={styles.doneBtnText}>Got it — let's go! →</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backBtn: { padding: 4, minWidth: 60 },
  backText: { color: Colors.primary, fontSize: 14, fontWeight: '600' },
  topTitle: { ...Typography.subtitle, color: Colors.text },

  content: { padding: Spacing.md, paddingBottom: 60 },

  hero: { ...Typography.hero, color: Colors.primary, marginTop: Spacing.sm },
  heroSub: { ...Typography.title, color: Colors.text, marginBottom: Spacing.sm },
  intro: {
    ...Typography.body,
    color: Colors.textSecondary,
    lineHeight: 22,
    marginBottom: Spacing.lg,
  },

  section: { marginBottom: Spacing.lg },
  sectionHeadingRow: {
    borderLeftWidth: 3,
    paddingLeft: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  sectionHeading: { ...Typography.subtitle, fontWeight: '700' },

  stepCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: Spacing.sm,
    overflow: 'hidden',
  },
  stepHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.md,
    gap: Spacing.sm,
  },
  stepIconWrap: {
    width: 36,
    height: 36,
    borderRadius: Radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepIcon: { fontSize: 18 },
  stepTitle: { ...Typography.body, color: Colors.text, fontWeight: '600', flex: 1 },
  chevron: { color: Colors.textMuted, fontSize: 14 },

  stepBody: {
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.md,
    gap: Spacing.sm,
  },
  stepDesc: { ...Typography.body, color: Colors.textSecondary, lineHeight: 21 },
  tipBox: {
    borderLeftWidth: 2,
    paddingLeft: Spacing.sm,
    gap: 2,
  },
  tipLabel: { ...Typography.label, color: Colors.textMuted, fontSize: 10 },
  tipText: { ...Typography.caption, color: Colors.textSecondary, lineHeight: 18 },

  quickRef: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.md,
    marginBottom: Spacing.lg,
    gap: 2,
  },
  quickRefTitle: { ...Typography.subtitle, color: Colors.text, marginBottom: Spacing.sm },
  quickRow: {
    flexDirection: 'row',
    paddingVertical: 7,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    gap: Spacing.sm,
    alignItems: 'flex-start',
  },
  quickLabel: {
    ...Typography.body,
    color: Colors.primary,
    fontWeight: '600',
    width: 100,
    flexShrink: 0,
  },
  quickDesc: { ...Typography.body, color: Colors.textSecondary, flex: 1, lineHeight: 20 },

  doneBtn: {
    backgroundColor: Colors.primary,
    borderRadius: Radius.full,
    padding: Spacing.md + 2,
    alignItems: 'center',
  },
  doneBtnText: { color: Colors.background, fontWeight: '800', fontSize: 15 },
});
