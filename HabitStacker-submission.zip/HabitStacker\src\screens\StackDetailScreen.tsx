import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useHabits } from '../context/HabitContext';
import { Colors, Spacing, Radius, Typography } from '../theme';
import { formatTime } from '../utils/dateUtils';
import { RootStackParamList } from '../navigation/AppNavigator';
import ProgressBar from '../components/ProgressBar';
import StreakBadge from '../components/StreakBadge';

type Nav = StackNavigationProp<RootStackParamList>;
type Route = RouteProp<RootStackParamList, 'StackDetail'>;

const CATEGORY_COLORS: Record<string, string> = {
  Health: Colors.tagHealth,
  Fitness: Colors.tagFitness,
  Focus: Colors.tagFocus,
  Skills: Colors.tagSkills,
};

export default function StackDetailScreen() {
  const nav = useNavigation<Nav>();
  const route = useRoute<Route>();
  const { stackId } = route.params;
  const { stacks, todayLog, streaks, toggleHabit, completionForStack } = useHabits();

  const stack = stacks.find(s => s.id === stackId);
  if (!stack) return null;

  const { done, total, isComplete } = completionForStack(stackId);
  const streak = streaks[stackId] ?? { current: 0, best: 0, lastCompletedDate: null };
  const log = todayLog[stackId];
  const habitsDone = log?.habitsDone ?? [];

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => nav.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => nav.navigate('StackBuilder', { stackId })}
          style={styles.editBtn}
        >
          <Text style={styles.editText}>Edit</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.stackName}>{stack.name}</Text>
        <View style={styles.metaRow}>
          <StreakBadge streak={streak.current} size="md" />
          {stack.reminderTime && (
            <Text style={styles.reminderText}>🔔 {formatTime(stack.reminderTime)}</Text>
          )}
          <Text style={styles.freqText}>{stack.frequency}</Text>
        </View>

        <View style={styles.progressSection}>
          <Text style={styles.progressText}>{Math.round((done / total) * 100)}% COMPLETE</Text>
          <ProgressBar progress={done / total} height={8} color={isComplete ? Colors.primary : Colors.accent} />
          <Text style={styles.progressCount}>{done} of {total} habits done</Text>
        </View>

        <Text style={styles.sectionLabel}>HABIT CHAIN</Text>

        {stack.habits.map((habit, idx) => {
          const isDone = habitsDone.includes(habit.id);
          const catColor = CATEGORY_COLORS[habit.category] ?? Colors.primary;
          const isNext = !isDone && idx === habitsDone.length;

          return (
            <TouchableOpacity
              key={habit.id}
              style={[
                styles.habitCard,
                isDone && styles.habitCardDone,
                isNext && styles.habitCardNext,
              ]}
              onPress={() => toggleHabit(stackId, habit.id)}
              activeOpacity={0.75}
            >
              <View style={[styles.numBadge, { backgroundColor: catColor + '25' }]}>
                <Text style={[styles.numText, { color: catColor }]}>
                  {isDone ? '✓' : idx + 1}
                </Text>
              </View>
              <Text style={styles.habitIcon}>{habit.icon}</Text>
              <View style={styles.habitInfo}>
                <Text style={[styles.habitName, isDone && styles.habitNameDone]}>
                  {habit.name}
                </Text>
                <Text style={styles.habitMeta}>
                  {habit.category}
                  {habit.durationMinutes ? ` · ${habit.durationMinutes} min` : ''}
                </Text>
              </View>
              {isNext && (
                <View style={styles.nextTag}>
                  <Text style={styles.nextTagText}>TAP TO CHECK</Text>
                </View>
              )}
              {!isDone && !isNext && (
                <Text style={styles.lockedIcon}>🔒</Text>
              )}
            </TouchableOpacity>
          );
        })}

        <TouchableOpacity
          style={styles.addToStack}
          onPress={() => nav.navigate('StackBuilder', { stackId })}
        >
          <Text style={styles.addToStackText}>+ ADD TO STACK</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backBtn: { padding: Spacing.xs },
  backText: { color: Colors.primary, fontSize: 14, fontWeight: '600' },
  editBtn: { padding: Spacing.xs },
  editText: { color: Colors.textSecondary, fontSize: 14 },

  content: { padding: Spacing.md, paddingBottom: 100 },

  stackName: { ...Typography.hero, color: Colors.text, marginBottom: Spacing.sm },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginBottom: Spacing.lg },
  reminderText: { ...Typography.caption, color: Colors.textSecondary },
  freqText: {
    ...Typography.caption,
    color: Colors.accent,
    backgroundColor: Colors.accent + '20',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: Radius.full,
  },

  progressSection: { marginBottom: Spacing.lg, gap: 6 },
  progressText: { ...Typography.label, color: Colors.primary },
  progressCount: { ...Typography.caption, color: Colors.textSecondary },

  sectionLabel: { ...Typography.label, color: Colors.textMuted, marginBottom: Spacing.sm },

  habitCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: Spacing.sm,
  },
  habitCardDone: {
    backgroundColor: Colors.completedBg,
    borderColor: Colors.primary + '30',
    opacity: 0.75,
  },
  habitCardNext: {
    borderColor: Colors.accent,
    backgroundColor: Colors.accent + '10',
  },
  numBadge: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  numText: { fontSize: 13, fontWeight: '700' },
  habitIcon: { fontSize: 22 },
  habitInfo: { flex: 1 },
  habitName: { ...Typography.body, color: Colors.text, fontWeight: '600' },
  habitNameDone: { textDecorationLine: 'line-through', color: Colors.textSecondary },
  habitMeta: { ...Typography.caption, color: Colors.textMuted, marginTop: 2 },
  nextTag: {
    backgroundColor: Colors.accent,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: Radius.full,
  },
  nextTagText: { fontSize: 9, fontWeight: '800', color: Colors.text, letterSpacing: 0.5 },
  lockedIcon: { fontSize: 16, opacity: 0.4 },

  addToStack: {
    marginTop: Spacing.md,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderStyle: 'dashed',
    borderRadius: Radius.md,
    padding: Spacing.md,
    alignItems: 'center',
  },
  addToStackText: { color: Colors.textSecondary, fontWeight: '600', fontSize: 13 },
});
