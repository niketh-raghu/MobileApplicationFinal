export type HabitCategory = 'Health' | 'Fitness' | 'Focus' | 'Skills';
export type HabitFrequency = 'Daily' | 'Weekdays' | 'Weekly';

export interface Habit {
  id: string;
  name: string;
  icon: string;
  category: HabitCategory;
  durationMinutes?: number;
}

export interface HabitStack {
  id: string;
  name: string;
  habits: Habit[];
  reminderTime: string | null; // "HH:MM" 24-hour
  frequency: HabitFrequency;
  createdAt: string;
}

export interface HabitCompletion {
  completed: boolean;
  habitsDone: string[]; // habit ids
  completedAt?: string; // ISO timestamp
}

// Key: stackId, Value: completion info for that day
export interface DailyLog {
  [stackId: string]: HabitCompletion;
}

export interface StreakData {
  current: number;
  lastCompletedDate: string | null; // YYYY-MM-DD
  best: number;
}

// Key: stackId, Value: streak
export interface AllStreaks {
  [stackId: string]: StreakData;
}

export interface AppSettings {
  notificationsEnabled: boolean;
}

export interface WeekDayStats {
  date: string; // YYYY-MM-DD
  label: string; // Mon, Tue...
  completed: number;
  total: number;
}
