export const Colors = {
  background: '#0F1117',
  surface: '#1A1D2E',
  surfaceAlt: '#12151F',
  border: '#2A2D3E',
  primary: '#00C896',
  primaryDim: '#00C89620',
  accent: '#7C4DFF',
  accentDim: '#7C4DFF20',
  gold: '#FFB800',
  goldDim: '#FFB80020',
  text: '#FFFFFF',
  textSecondary: '#8B8FA8',
  textMuted: '#4A4D5E',
  success: '#00C896',
  danger: '#FF4757',
  tagHealth: '#00C896',
  tagFitness: '#FF6B35',
  tagFocus: '#7C4DFF',
  tagSkills: '#FFB800',
  tabBar: '#12151F',
  tabBarBorder: '#1E2130',
  cardBorder: '#2A2D3E',
  streakBanner: '#1E2A1E',
  completedBg: '#00C89610',
};

export const Typography = {
  hero: { fontSize: 28, fontWeight: '700' as const },
  title: { fontSize: 20, fontWeight: '700' as const },
  subtitle: { fontSize: 16, fontWeight: '600' as const },
  body: { fontSize: 14, fontWeight: '400' as const },
  caption: { fontSize: 12, fontWeight: '400' as const },
  label: { fontSize: 11, fontWeight: '600' as const, letterSpacing: 0.8 },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
};
