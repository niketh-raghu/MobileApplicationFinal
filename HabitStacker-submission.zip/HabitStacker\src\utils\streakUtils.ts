import { StreakData } from '../types';
import { todayString, dateDiffDays } from './dateUtils';

export function computeUpdatedStreak(
  existing: StreakData | undefined,
  completedToday: boolean
): StreakData {
  const today = todayString();
  const prev: StreakData = existing ?? { current: 0, lastCompletedDate: null, best: 0 };

  if (!completedToday) {
    // Check if streak should be broken (missed yesterday)
    if (prev.lastCompletedDate) {
      const diff = dateDiffDays(prev.lastCompletedDate, today);
      if (diff > 1) {
        // Missed at least one day — streak broken, but keep best
        return { current: 0, lastCompletedDate: prev.lastCompletedDate, best: prev.best };
      }
    }
    return prev;
  }

  // Completing today
  if (prev.lastCompletedDate === today) {
    // Already completed today — no change
    return prev;
  }

  let newCurrent: number;
  if (!prev.lastCompletedDate) {
    newCurrent = 1;
  } else {
    const diff = dateDiffDays(prev.lastCompletedDate, today);
    newCurrent = diff === 1 ? prev.current + 1 : 1; // consecutive or restart
  }

  const newBest = Math.max(newCurrent, prev.best);
  return { current: newCurrent, lastCompletedDate: today, best: newBest };
}

export function shouldBreakStreak(streak: StreakData): boolean {
  if (!streak.lastCompletedDate) return false;
  const today = todayString();
  const diff = dateDiffDays(streak.lastCompletedDate, today);
  return diff > 1;
}
