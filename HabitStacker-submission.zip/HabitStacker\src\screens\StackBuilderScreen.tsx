import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, ScrollView, TouchableOpacity,
  StyleSheet, SafeAreaView, Alert, Modal, Platform,
} from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useHabits } from '../context/HabitContext';
import { Colors, Spacing, Radius, Typography } from '../theme';
import { RootStackParamList } from '../navigation/AppNavigator';
import { Habit, HabitCategory, HabitFrequency } from '../types';
import CategoryChip from '../components/CategoryChip';

type Nav = StackNavigationProp<RootStackParamList>;
type Route = RouteProp<RootStackParamList, 'StackBuilder'>;

const CATEGORIES: HabitCategory[] = ['Health', 'Fitness', 'Focus', 'Skills'];
const FREQUENCIES: HabitFrequency[] = ['Daily', 'Weekdays', 'Weekly'];

const ICONS = [
  '🧘','🏃','💧','📖','🎯','💪','🥗','😴','✍️','🎵',
  '🧠','🌿','⚡','🔥','🏋️','🚴','🚶','🎨','💻','🌅',
  '🍎','☕','🏊','🧹','📝','🎤','🎮','🌙','☀️','🦷',
];

const HOURS = Array.from({ length: 24 }, (_, i) => i);
const MINUTES = [0, 15, 30, 45];

function generateId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

interface HabitFormState {
  name: string;
  icon: string;
  category: HabitCategory;
  durationMinutes: string;
}

const defaultHabitForm: HabitFormState = {
  name: '',
  icon: '⚡',
  category: 'Health',
  durationMinutes: '',
};

export default function StackBuilderScreen() {
  const nav = useNavigation<Nav>();
  const route = useRoute<Route>();
  const { stackId } = route.params ?? {};
  const { stacks, addStack, updateStack } = useHabits();

  const existing = stackId ? stacks.find(s => s.id === stackId) : undefined;

  const [stackName, setStackName] = useState(existing?.name ?? '');
  const [habits, setHabits] = useState<Habit[]>(existing?.habits ?? []);
  const [frequency, setFrequency] = useState<HabitFrequency>(existing?.frequency ?? 'Daily');
  const [reminderHour, setReminderHour] = useState<number | null>(
    existing?.reminderTime ? parseInt(existing.reminderTime.split(':')[0]) : null
  );
  const [reminderMinute, setReminderMinute] = useState<number>(
    existing?.reminderTime ? parseInt(existing.reminderTime.split(':')[1]) : 0
  );
  const [reminderEnabled, setReminderEnabled] = useState(!!existing?.reminderTime);

  const [habitForm, setHabitForm] = useState<HabitFormState>(defaultHabitForm);
  const [editingHabitId, setEditingHabitId] = useState<string | null>(null);
  const [showHabitModal, setShowHabitModal] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);

  const isEditing = !!existing;

  function openAddHabit() {
    setHabitForm(defaultHabitForm);
    setEditingHabitId(null);
    setShowHabitModal(true);
  }

  function openEditHabit(habit: Habit) {
    setHabitForm({
      name: habit.name,
      icon: habit.icon,
      category: habit.category,
      durationMinutes: habit.durationMinutes?.toString() ?? '',
    });
    setEditingHabitId(habit.id);
    setShowHabitModal(true);
  }

  function saveHabit() {
    if (!habitForm.name.trim()) {
      Alert.alert('Name required', 'Please give this habit a name.');
      return;
    }
    const newHabit: Habit = {
      id: editingHabitId ?? generateId(),
      name: habitForm.name.trim(),
      icon: habitForm.icon,
      category: habitForm.category,
      durationMinutes: habitForm.durationMinutes ? parseInt(habitForm.durationMinutes) : undefined,
    };
    if (editingHabitId) {
      setHabits(prev => prev.map(h => h.id === editingHabitId ? newHabit : h));
    } else {
      if (habits.length >= 5) {
        Alert.alert('Max 5 habits', 'A stack can hold at most 5 habits.');
        return;
      }
      setHabits(prev => [...prev, newHabit]);
    }
    setShowHabitModal(false);
  }

  function removeHabit(id: string) {
    setHabits(prev => prev.filter(h => h.id !== id));
  }

  function moveHabit(idx: number, dir: -1 | 1) {
    const newHabits = [...habits];
    const target = idx + dir;
    if (target < 0 || target >= newHabits.length) return;
    [newHabits[idx], newHabits[target]] = [newHabits[target], newHabits[idx]];
    setHabits(newHabits);
  }

  async function handleSave() {
    if (!stackName.trim()) {
      Alert.alert('Stack name required', 'Please name your stack.');
      return;
    }
    if (habits.length < 2) {
      Alert.alert('Add more habits', 'A stack needs at least 2 habits.');
      return;
    }

    const reminderTime = reminderEnabled && reminderHour !== null
      ? `${String(reminderHour).padStart(2, '0')}:${String(reminderMinute).padStart(2, '0')}`
      : null;

    const stack = {
      id: existing?.id ?? generateId(),
      name: stackName.trim(),
      habits,
      frequency,
      reminderTime,
      createdAt: existing?.createdAt ?? new Date().toISOString(),
    };

    try {
      if (isEditing) {
        await updateStack(stack);
      } else {
        await addStack(stack);
      }
      if (nav.canGoBack()) {
        nav.goBack();
      } else {
        nav.navigate('MainTabs');
      }
    } catch (e) {
      Alert.alert('Error', 'Could not save your stack. Please try again.');
    }
  }

  const formatReminderDisplay = () => {
    if (!reminderEnabled || reminderHour === null) return 'Not set';
    const h = reminderHour;
    const period = h >= 12 ? 'PM' : 'AM';
    const display = h % 12 === 0 ? 12 : h % 12;
    return `${display}:${String(reminderMinute).padStart(2, '0')} ${period}`;
  };

  return (
    <SafeAreaView style={styles.safe}>
      {/* Top Bar */}
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => nav.canGoBack() ? nav.goBack() : nav.navigate('MainTabs')} style={styles.topBtn}>
          <Text style={styles.cancelText}>Cancel</Text>
        </TouchableOpacity>
        <Text style={styles.topTitle}>{isEditing ? 'Edit Stack' : '+ Add New Habit'}</Text>
        <TouchableOpacity onPress={handleSave} style={styles.saveBtn}>
          <Text style={styles.saveText}>Save</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {/* Stack Name */}
        <Text style={styles.fieldLabel}>STACK NAME</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. Morning Stack"
          placeholderTextColor={Colors.textMuted}
          value={stackName}
          onChangeText={setStackName}
        />

        {/* Frequency */}
        <Text style={styles.fieldLabel}>FREQUENCY</Text>
        <View style={styles.chipRow}>
          {FREQUENCIES.map(f => (
            <TouchableOpacity
              key={f}
              style={[styles.freqChip, frequency === f && styles.freqChipActive]}
              onPress={() => setFrequency(f)}
            >
              <Text style={[styles.freqChipText, frequency === f && styles.freqChipTextActive]}>
                {f.toUpperCase()}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Reminder */}
        <Text style={styles.fieldLabel}>REMINDER TIME</Text>
        <View style={styles.reminderRow}>
          <TouchableOpacity
            style={styles.reminderToggle}
            onPress={() => setReminderEnabled(v => !v)}
          >
            <View style={[styles.toggle, reminderEnabled && styles.toggleOn]}>
              <View style={[styles.toggleThumb, reminderEnabled && styles.toggleThumbOn]} />
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.reminderPicker, !reminderEnabled && styles.reminderPickerDisabled]}
            onPress={() => reminderEnabled && setShowTimePicker(true)}
          >
            <Text style={[styles.reminderPickerText, !reminderEnabled && { color: Colors.textMuted }]}>
              🔔 {formatReminderDisplay()}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Habits */}
        <View style={styles.sectionHeader}>
          <Text style={styles.fieldLabel}>HABITS ({habits.length}/5)</Text>
          {habits.length < 5 && (
            <TouchableOpacity onPress={openAddHabit} style={styles.addHabitBtn}>
              <Text style={styles.addHabitBtnText}>+ ADD HABIT</Text>
            </TouchableOpacity>
          )}
        </View>

        {habits.length === 0 && (
          <TouchableOpacity style={styles.emptyHabitsCard} onPress={openAddHabit}>
            <Text style={styles.emptyHabitsText}>Tap to add your first habit</Text>
          </TouchableOpacity>
        )}

        {habits.map((habit, idx) => (
          <View key={habit.id} style={styles.habitCard}>
            <View style={styles.habitCardLeft}>
              <Text style={styles.habitCardNum}>{idx + 1}</Text>
              <Text style={styles.habitCardIcon}>{habit.icon}</Text>
              <View>
                <Text style={styles.habitCardName}>{habit.name}</Text>
                <Text style={styles.habitCardMeta}>
                  {habit.category}
                  {habit.durationMinutes ? ` · ${habit.durationMinutes} min` : ''}
                </Text>
              </View>
            </View>
            <View style={styles.habitCardActions}>
              <TouchableOpacity onPress={() => moveHabit(idx, -1)} disabled={idx === 0}>
                <Text style={[styles.arrowBtn, idx === 0 && styles.arrowDisabled]}>↑</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => moveHabit(idx, 1)} disabled={idx === habits.length - 1}>
                <Text style={[styles.arrowBtn, idx === habits.length - 1 && styles.arrowDisabled]}>↓</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => openEditHabit(habit)}>
                <Text style={styles.editHabitBtn}>✏️</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => removeHabit(habit.id)}>
                <Text style={styles.removeHabitBtn}>✕</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}

        {habits.length >= 2 && (
          <TouchableOpacity style={styles.saveStackBtn} onPress={handleSave}>
            <Text style={styles.saveStackBtnText}>SAVE HABIT STACK</Text>
          </TouchableOpacity>
        )}
      </ScrollView>

      {/* Habit Form Modal */}
      <Modal visible={showHabitModal} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={styles.modal}>
          <View style={styles.modalTopBar}>
            <TouchableOpacity onPress={() => setShowHabitModal(false)}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>
              {editingHabitId ? 'Edit Habit' : 'New Habit'}
            </Text>
            <TouchableOpacity onPress={saveHabit}>
              <Text style={styles.saveText}>Done</Text>
            </TouchableOpacity>
          </View>

          <ScrollView contentContainerStyle={styles.modalContent} keyboardShouldPersistTaps="handled">
            <Text style={styles.fieldLabel}>HABIT NAME</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g. Morning Meditation"
              placeholderTextColor={Colors.textMuted}
              value={habitForm.name}
              onChangeText={v => setHabitForm(f => ({ ...f, name: v }))}
              autoFocus
            />

            <Text style={styles.fieldLabel}>PICK AN ICON</Text>
            <View style={styles.iconGrid}>
              {ICONS.map(icon => (
                <TouchableOpacity
                  key={icon}
                  style={[styles.iconBtn, habitForm.icon === icon && styles.iconBtnSelected]}
                  onPress={() => setHabitForm(f => ({ ...f, icon }))}
                >
                  <Text style={{ fontSize: 22 }}>{icon}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.fieldLabel}>CATEGORY</Text>
            <View style={styles.chipRow}>
              {CATEGORIES.map(cat => (
                <CategoryChip
                  key={cat}
                  category={cat}
                  selected={habitForm.category === cat}
                  onPress={() => setHabitForm(f => ({ ...f, category: cat }))}
                />
              ))}
            </View>

            <Text style={styles.fieldLabel}>DURATION (OPTIONAL)</Text>
            <TextInput
              style={[styles.input, styles.inputShort]}
              placeholder="Minutes (e.g. 10)"
              placeholderTextColor={Colors.textMuted}
              value={habitForm.durationMinutes}
              onChangeText={v => setHabitForm(f => ({ ...f, durationMinutes: v.replace(/[^0-9]/g, '') }))}
              keyboardType="numeric"
            />
          </ScrollView>
        </SafeAreaView>
      </Modal>

      {/* Time Picker Modal */}
      <Modal visible={showTimePicker} animationType="fade" transparent>
        <View style={styles.timePickerOverlay}>
          <View style={styles.timePickerCard}>
            <Text style={styles.timePickerTitle}>Set Reminder Time</Text>
            <View style={styles.timePickerRow}>
              {/* Hour column */}
              <ScrollView style={styles.timeCol} showsVerticalScrollIndicator={false}>
                {HOURS.map(h => (
                  <TouchableOpacity
                    key={h}
                    style={[styles.timeCell, reminderHour === h && styles.timeCellSelected]}
                    onPress={() => setReminderHour(h)}
                  >
                    <Text style={[styles.timeCellText, reminderHour === h && styles.timeCellTextSelected]}>
                      {h % 12 === 0 ? 12 : h % 12} {h >= 12 ? 'PM' : 'AM'}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
              <Text style={styles.timeColon}>:</Text>
              {/* Minute column */}
              <View style={styles.timeCol}>
                {MINUTES.map(m => (
                  <TouchableOpacity
                    key={m}
                    style={[styles.timeCell, reminderMinute === m && styles.timeCellSelected]}
                    onPress={() => setReminderMinute(m)}
                  >
                    <Text style={[styles.timeCellText, reminderMinute === m && styles.timeCellTextSelected]}>
                      {String(m).padStart(2, '0')}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            <TouchableOpacity style={styles.timePickerDone} onPress={() => setShowTimePicker(false)}>
              <Text style={styles.timePickerDoneText}>Done</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  topBtn: { padding: 4 },
  topTitle: { ...Typography.subtitle, color: Colors.text },
  cancelText: { color: Colors.textSecondary, fontSize: 14 },
  saveBtn: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: Radius.full,
  },
  saveText: { color: Colors.background, fontWeight: '700', fontSize: 13 },

  scroll: { flex: 1 },
  content: { padding: Spacing.md, paddingBottom: 100 },

  fieldLabel: {
    ...Typography.label,
    color: Colors.textMuted,
    marginBottom: Spacing.sm,
    marginTop: Spacing.md,
  },

  input: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    color: Colors.text,
    fontSize: 15,
    padding: Spacing.md,
  },
  inputShort: { width: 140 },

  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },

  freqChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: Radius.full,
    borderWidth: 1.5,
    borderColor: Colors.border,
  },
  freqChipActive: { borderColor: Colors.primary, backgroundColor: Colors.primary + '25' },
  freqChipText: { fontSize: 12, fontWeight: '700', color: Colors.textSecondary, letterSpacing: 0.5 },
  freqChipTextActive: { color: Colors.primary },

  reminderRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  reminderToggle: { padding: 4 },
  toggle: {
    width: 44,
    height: 24,
    borderRadius: 12,
    backgroundColor: Colors.border,
    justifyContent: 'center',
    padding: 2,
  },
  toggleOn: { backgroundColor: Colors.primary },
  toggleThumb: { width: 20, height: 20, borderRadius: 10, backgroundColor: Colors.text },
  toggleThumbOn: { alignSelf: 'flex-end' },
  reminderPicker: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.sm + 4,
  },
  reminderPickerDisabled: { opacity: 0.5 },
  reminderPickerText: { color: Colors.text, fontSize: 14 },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: Spacing.md,
    marginBottom: Spacing.sm,
  },
  addHabitBtn: {
    backgroundColor: Colors.accent + '25',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: Radius.full,
  },
  addHabitBtnText: { color: Colors.accent, fontSize: 11, fontWeight: '700' },

  emptyHabitsCard: {
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderStyle: 'dashed',
    borderRadius: Radius.md,
    padding: Spacing.lg,
    alignItems: 'center',
  },
  emptyHabitsText: { color: Colors.textMuted, fontSize: 13 },

  habitCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.sm + 4,
    marginBottom: Spacing.sm,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  habitCardLeft: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  habitCardNum: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: Colors.primary + '20',
    color: Colors.primary,
    fontSize: 12,
    fontWeight: '700',
    textAlign: 'center',
    lineHeight: 22,
  },
  habitCardIcon: { fontSize: 20 },
  habitCardName: { ...Typography.body, color: Colors.text, fontWeight: '600' },
  habitCardMeta: { ...Typography.caption, color: Colors.textMuted },
  habitCardActions: { flexDirection: 'row', gap: 6, alignItems: 'center' },
  arrowBtn: { color: Colors.textSecondary, fontSize: 16, padding: 4, fontWeight: '700' },
  arrowDisabled: { opacity: 0.2 },
  editHabitBtn: { fontSize: 14, padding: 4 },
  removeHabitBtn: { color: Colors.danger, fontSize: 14, fontWeight: '700', padding: 4 },

  saveStackBtn: {
    backgroundColor: Colors.primary,
    borderRadius: Radius.full,
    padding: Spacing.md,
    alignItems: 'center',
    marginTop: Spacing.lg,
  },
  saveStackBtnText: { color: Colors.background, fontWeight: '800', fontSize: 14, letterSpacing: 0.5 },

  // Modal
  modal: { flex: 1, backgroundColor: Colors.background },
  modalTopBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  modalTitle: { ...Typography.subtitle, color: Colors.text },
  modalContent: { padding: Spacing.md, paddingBottom: 80 },

  iconGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: Spacing.sm,
  },
  iconBtn: {
    width: 48,
    height: 48,
    borderRadius: Radius.md,
    backgroundColor: Colors.surface,
    borderWidth: 1.5,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconBtnSelected: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primary + '25',
  },

  // Time Picker
  timePickerOverlay: {
    flex: 1,
    backgroundColor: '#00000080',
    justifyContent: 'center',
    alignItems: 'center',
  },
  timePickerCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    width: 280,
  },
  timePickerTitle: { ...Typography.subtitle, color: Colors.text, textAlign: 'center', marginBottom: Spacing.md },
  timePickerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', height: 200 },
  timeCol: { flex: 1 },
  timeColon: { color: Colors.text, fontSize: 24, fontWeight: '700', marginHorizontal: 8 },
  timeCell: {
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderRadius: Radius.sm,
    alignItems: 'center',
  },
  timeCellSelected: { backgroundColor: Colors.primary + '30' },
  timeCellText: { color: Colors.textSecondary, fontSize: 14 },
  timeCellTextSelected: { color: Colors.primary, fontWeight: '700' },
  timePickerDone: {
    backgroundColor: Colors.primary,
    borderRadius: Radius.full,
    padding: Spacing.sm + 4,
    alignItems: 'center',
    marginTop: Spacing.md,
  },
  timePickerDoneText: { color: Colors.background, fontWeight: '700' },
});
