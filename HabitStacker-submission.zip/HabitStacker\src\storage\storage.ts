import AsyncStorage from '@react-native-async-storage/async-storage';
import { HabitStack, DailyLog, AllStreaks, AppSettings } from '../types';

const KEYS = {
  STACKS: 'habitstacker_stacks',
  STREAKS: 'habitstacker_streaks',
  SETTINGS: 'habitstacker_settings',
  dailyLog: (date: string) => `habitstacker_log_${date}`,
};

// --- Stacks ---

export async function loadStacks(): Promise<HabitStack[]> {
  const raw = await AsyncStorage.getItem(KEYS.STACKS);
  return raw ? JSON.parse(raw) : [];
}

export async function saveStacks(stacks: HabitStack[]): Promise<void> {
  await AsyncStorage.setItem(KEYS.STACKS, JSON.stringify(stacks));
}

// --- Daily Logs ---

export async function loadDailyLog(date: string): Promise<DailyLog> {
  const raw = await AsyncStorage.getItem(KEYS.dailyLog(date));
  return raw ? JSON.parse(raw) : {};
}

export async function saveDailyLog(date: string, log: DailyLog): Promise<void> {
  await AsyncStorage.setItem(KEYS.dailyLog(date), JSON.stringify(log));
}

export async function loadLogsForRange(dates: string[]): Promise<Record<string, DailyLog>> {
  const pairs = await AsyncStorage.multiGet(dates.map(KEYS.dailyLog));
  const result: Record<string, DailyLog> = {};
  for (const [key, value] of pairs) {
    const date = key.replace('habitstacker_log_', '');
    result[date] = value ? JSON.parse(value) : {};
  }
  return result;
}

// --- Streaks ---

export async function loadStreaks(): Promise<AllStreaks> {
  const raw = await AsyncStorage.getItem(KEYS.STREAKS);
  return raw ? JSON.parse(raw) : {};
}

export async function saveStreaks(streaks: AllStreaks): Promise<void> {
  await AsyncStorage.setItem(KEYS.STREAKS, JSON.stringify(streaks));
}

// --- Settings ---

export async function loadSettings(): Promise<AppSettings> {
  const raw = await AsyncStorage.getItem(KEYS.SETTINGS);
  return raw ? JSON.parse(raw) : { notificationsEnabled: true };
}

export async function saveSettings(settings: AppSettings): Promise<void> {
  await AsyncStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
}

// --- Reset ---

export async function clearAllData(): Promise<void> {
  const keys = await AsyncStorage.getAllKeys();
  const appKeys = keys.filter(k => k.startsWith('habitstacker_'));
  await AsyncStorage.multiRemove(appKeys);
}
