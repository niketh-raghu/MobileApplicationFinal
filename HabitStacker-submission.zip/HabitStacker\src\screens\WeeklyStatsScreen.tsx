import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, SafeAreaView, StatusBar,
} from 'react-native';
import { useHabits } from '../context/HabitContext';
import { Colors, Spacing, Radius, Typography } from '../theme';
import { loadLogsForRange } from '../storage/storage';
import { last7Days, todayString } from '../utils/dateUtils';
import { buildWeekStats, overallCompletionRate, totalHabitsDoneThisWeek } from '../utils/statsUtils';
import { DailyLog, WeekDayStats } from '../types';

export default function WeeklyStatsScreen() {
  const { stacks, streaks } = useHabits();
  const [weekStats, setWeekStats] = useState<WeekDayStats[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const days = last7Days();
      const logs = await loadLogsForRange(days);
      const stats = buildWeekStats(stacks, logs);
      setWeekStats(stats);
      setLoading(false);
    }
    load();
  }, [stacks]);

  const completionRate = overallCompletionRate(weekStats);
  const habitsDone = totalHabitsDoneThisWeek(weekStats);
  const totalSlots = weekStats.reduce((s, d) => s + d.total, 0);
  const bestStreak = Math.max(0, ...Object.values(streaks).map(s => s.current));
  const bestStreakBest = Math.max(0, ...Object.values(streaks).map(s => s.best));
  const totalTime = stacks.reduce((sum, stack) => {
    const mins = stack.habits.reduce((s, h) => s + (h.durationMinutes ?? 0), 0);
    return sum + mins;
  }, 0);

  const maxBar = Math.max(1, ...weekStats.map(d => d.total));
  const today = todayString();

  if (loading) {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.loading}>
          <Text style={styles.loadingText}>Loading stats...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const bestHabit = stacks.reduce<{ name: string; streak: number } | null>((best, s) => {
    const sr = streaks[s.id]?.current ?? 0;
    if (!best || sr > best.streak) return { name: s.name, streak: sr };
    return best;
  }, null);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.background} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.dateRange}>
            {weekStats[0]?.label ?? 'Mon'} – {weekStats[6]?.label ?? 'Sun'}
          </Text>
          <Text style={styles.title}>📊 Weekly Stats</Text>
        </View>

        {/* Bar Chart */}
        <View style={styles.chartCard}>
          <View style={styles.chartBars}>
            {weekStats.map(day => {
              const isToday = day.date === today;
              const height = day.total > 0 ? (day.completed / maxBar) * 120 : 4;
              const color = isToday ? Colors.primary : day.completed === day.total && day.total > 0
                ? Colors.primary + 'AA' : Colors.accent + '60';

              return (
                <View key={day.date} style={styles.barCol}>
                  <Text style={styles.barCount}>
                    {day.total > 0 ? `${day.completed}/${day.total}` : ''}
                  </Text>
                  <View style={styles.barTrack}>
                    <View
                      style={[
                        styles.barFill,
                        { height: Math.max(4, height), backgroundColor: color },
                        isToday && styles.barToday,
                      ]}
                    />
                  </View>
                  <Text style={[styles.barLabel, isToday && styles.barLabelToday]}>
                    {day.label}
                  </Text>
                  {isToday && <View style={styles.todayDot} />}
                </View>
              );
            })}
          </View>
        </View>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>🔥</Text>
            <Text style={styles.statValue}>{bestStreak}</Text>
            <Text style={styles.statLabel}>Day Streak</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>📈</Text>
            <Text style={styles.statValue}>{completionRate}%</Text>
            <Text style={styles.statLabel}>Completion Rate</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>✅</Text>
            <Text style={styles.statValue}>{habitsDone}/{totalSlots}</Text>
            <Text style={styles.statLabel}>Stacks Done</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>⏱️</Text>
            <Text style={styles.statValue}>{totalTime > 0 ? `${(totalTime / 60).toFixed(1)}h` : '—'}</Text>
            <Text style={styles.statLabel}>Total Time</Text>
          </View>
        </View>

        {/* Best Habit Card */}
        {bestHabit && bestHabit.streak > 0 && (
          <View style={styles.bestCard}>
            <View style={styles.bestCardLeft}>
              <Text style={styles.bestCardLabel}>⭐ Best Stack This Week</Text>
              <Text style={styles.bestCardName}>{bestHabit.name}</Text>
            </View>
            <View style={styles.bestStreakBadge}>
              <Text style={styles.bestStreakText}>🔥 {bestHabit.streak}/7 days</Text>
            </View>
          </View>
        )}

        {/* Per-stack breakdown */}
        {stacks.length > 0 && (
          <>
            <Text style={styles.sectionLabel}>STACK BREAKDOWN</Text>
            {stacks.map(stack => {
              const streak = streaks[stack.id] ?? { current: 0, best: 0, lastCompletedDate: null };
              const stackDays = weekStats.filter(d => {
                // We'll approximate from weekStats if completed
                return true;
              });
              const daysCompleted = weekStats.filter(d => {
                // This would need per-stack log data; approximate via current streak
                return false;
              }).length;

              return (
                <View key={stack.id} style={styles.stackBreakdown}>
                  <View style={styles.stackBreakdownLeft}>
                    <Text style={styles.stackBreakdownName}>{stack.name}</Text>
                    <Text style={styles.stackBreakdownMeta}>
                      {stack.habits.length} habits · {stack.frequency}
                    </Text>
                  </View>
                  <View style={styles.stackBreakdownRight}>
                    <Text style={styles.streakVal}>🔥 {streak.current}</Text>
                    <Text style={styles.bestVal}>Best: {streak.best}</Text>
                  </View>
                </View>
              );
            })}
          </>
        )}

        {stacks.length === 0 && (
          <View style={styles.noData}>
            <Text style={styles.noDataEmoji}>📭</Text>
            <Text style={styles.noDataTitle}>No data yet</Text>
            <Text style={styles.noDataSub}>Create your first habit stack to start tracking.</Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loadingText: { color: Colors.textSecondary },
  content: { padding: Spacing.md, paddingBottom: 100 },

  header: { marginBottom: Spacing.md },
  dateRange: { ...Typography.caption, color: Colors.textMuted },
  title: { ...Typography.title, color: Colors.text, marginTop: 2 },

  chartCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.md,
    marginBottom: Spacing.md,
  },
  chartBars: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 160,
  },
  barCol: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 4,
  },
  barCount: { ...Typography.label, color: Colors.textMuted, fontSize: 9 },
  barTrack: {
    width: 28,
    height: 120,
    justifyContent: 'flex-end',
    backgroundColor: '#FFFFFF08',
    borderRadius: Radius.sm,
    overflow: 'hidden',
  },
  barFill: {
    width: '100%',
    borderRadius: Radius.sm,
  },
  barToday: {
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 6,
    elevation: 4,
  },
  barLabel: { ...Typography.label, color: Colors.textMuted, fontSize: 10 },
  barLabelToday: { color: Colors.primary },
  todayDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: Colors.primary,
  },

  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.md,
    alignItems: 'center',
    gap: 4,
  },
  statIcon: { fontSize: 22 },
  statValue: { ...Typography.subtitle, color: Colors.text, fontWeight: '700' },
  statLabel: { ...Typography.caption, color: Colors.textSecondary, textAlign: 'center' },

  bestCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.gold + '15',
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.gold + '30',
    padding: Spacing.md,
    marginBottom: Spacing.md,
  },
  bestCardLeft: { flex: 1 },
  bestCardLabel: { ...Typography.caption, color: Colors.gold, fontWeight: '600' },
  bestCardName: { ...Typography.subtitle, color: Colors.text, marginTop: 2 },
  bestStreakBadge: {
    backgroundColor: Colors.gold + '20',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: Radius.full,
  },
  bestStreakText: { color: Colors.gold, fontSize: 12, fontWeight: '700' },

  sectionLabel: { ...Typography.label, color: Colors.textMuted, marginBottom: Spacing.sm },

  stackBreakdown: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
  },
  stackBreakdownLeft: { flex: 1 },
  stackBreakdownName: { ...Typography.body, color: Colors.text, fontWeight: '600' },
  stackBreakdownMeta: { ...Typography.caption, color: Colors.textMuted, marginTop: 2 },
  stackBreakdownRight: { alignItems: 'flex-end' },
  streakVal: { fontSize: 14, fontWeight: '700', color: Colors.gold },
  bestVal: { ...Typography.caption, color: Colors.textMuted },

  noData: { alignItems: 'center', paddingVertical: Spacing.xl * 2 },
  noDataEmoji: { fontSize: 48, marginBottom: Spacing.md },
  noDataTitle: { ...Typography.subtitle, color: Colors.text, marginBottom: Spacing.xs },
  noDataSub: { ...Typography.body, color: Colors.textSecondary, textAlign: 'center' },
});
