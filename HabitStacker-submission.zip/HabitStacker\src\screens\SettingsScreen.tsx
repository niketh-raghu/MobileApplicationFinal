import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  SafeAreaView, StatusBar, Alert, Linking,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useHabits } from '../context/HabitContext';
import { Colors, Spacing, Radius, Typography } from '../theme';
import { RootStackParamList } from '../navigation/AppNavigator';
import * as Notifications from 'expo-notifications';

type Nav = StackNavigationProp<RootStackParamList>;

export default function SettingsScreen() {
  const nav = useNavigation<Nav>();
  const { settings, updateSettings, resetAllData, stacks, streaks } = useHabits();
  const [permissionDenied, setPermissionDenied] = useState(false);

  async function handleToggleNotifications() {
    const newValue = !settings.notificationsEnabled;

    if (newValue) {
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== 'granted') {
        setPermissionDenied(true);
        Alert.alert(
          'Notifications Disabled',
          'To receive reminders, enable notifications for HabitStacker in your device Settings.',
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Open Settings', onPress: () => Linking.openSettings() },
          ]
        );
        return;
      }
      setPermissionDenied(false);
    }

    await updateSettings({ ...settings, notificationsEnabled: newValue });
  }

  function handleResetData() {
    Alert.alert(
      'Reset All Data',
      'This will permanently delete all your stacks, habits, streaks, and history. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset Everything',
          style: 'destructive',
          onPress: async () => {
            await resetAllData();
          },
        },
      ]
    );
  }

  const totalStreakDays = Object.values(streaks).reduce((sum, s) => sum + s.current, 0);
  const bestEver = Math.max(0, ...Object.values(streaks).map(s => s.best));

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.background} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>🔔 Reminders</Text>
        <Text style={styles.subtitle}>Tap any reminder to edit · Toggle to pause</Text>

        {/* Notification Toggle */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>NOTIFICATIONS</Text>

          {permissionDenied && (
            <View style={styles.permissionWarning}>
              <Text style={styles.permissionWarningText}>
                ⚠️ Notifications are blocked. Open Settings to enable them.
              </Text>
              <TouchableOpacity onPress={() => Linking.openSettings()}>
                <Text style={styles.permissionLink}>Open Settings →</Text>
              </TouchableOpacity>
            </View>
          )}

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Daily Reminders</Text>
              <Text style={styles.settingDesc}>
                Get notified when it's time for your habit stacks
              </Text>
            </View>
            <TouchableOpacity onPress={handleToggleNotifications} activeOpacity={0.8}>
              <View style={[styles.toggle, settings.notificationsEnabled && styles.toggleOn]}>
                <View style={[styles.toggleThumb, settings.notificationsEnabled && styles.toggleThumbOn]} />
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {/* Per-stack reminders */}
        {stacks.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>STACK REMINDERS</Text>
            {stacks.map(stack => {
              const hasReminder = !!stack.reminderTime;
              return (
                <View key={stack.id} style={styles.reminderCard}>
                  <View style={styles.reminderCardLeft}>
                    <Text style={styles.reminderStackName}>{stack.name}</Text>
                    {hasReminder ? (
                      <View style={styles.activeBadge}>
                        <Text style={styles.activeBadgeText}>Active</Text>
                      </View>
                    ) : (
                      <View style={styles.noBadge}>
                        <Text style={styles.noBadgeText}>No reminder</Text>
                      </View>
                    )}
                  </View>
                  <View style={styles.reminderCardRight}>
                    <Text style={styles.reminderTime}>
                      {hasReminder ? formatTime(stack.reminderTime!) : '—'}
                    </Text>
                    <View style={[
                      styles.reminderToggle,
                      hasReminder && settings.notificationsEnabled && styles.reminderToggleOn,
                    ]}>
                      <View style={[
                        styles.toggleThumb,
                        hasReminder && settings.notificationsEnabled && styles.toggleThumbOn,
                      ]} />
                    </View>
                  </View>
                </View>
              );
            })}
          </View>
        )}

        {/* Stats Summary */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>YOUR STATS</Text>
          <View style={styles.statsRow}>
            <View style={styles.statBox}>
              <Text style={styles.statValue}>{stacks.length}</Text>
              <Text style={styles.statLabel}>Stacks</Text>
            </View>
            <View style={styles.statBox}>
              <Text style={styles.statValue}>{stacks.reduce((s, st) => s + st.habits.length, 0)}</Text>
              <Text style={styles.statLabel}>Habits</Text>
            </View>
            <View style={styles.statBox}>
              <Text style={styles.statValue}>{bestEver}</Text>
              <Text style={styles.statLabel}>Best Streak</Text>
            </View>
          </View>
        </View>

        {/* How To Use */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>HELP</Text>
          <TouchableOpacity style={styles.helpBtn} onPress={() => nav.navigate('HowToUse')}>
            <Text style={styles.helpBtnIcon}>📖</Text>
            <View style={styles.helpBtnInfo}>
              <Text style={styles.helpBtnTitle}>How to Use HabitStacker</Text>
              <Text style={styles.helpBtnDesc}>Learn about stacks, streaks, reminders, and more</Text>
            </View>
            <Text style={styles.helpChevron}>›</Text>
          </TouchableOpacity>
        </View>

        {/* Danger Zone */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>DATA</Text>
          <TouchableOpacity style={styles.dangerBtn} onPress={handleResetData}>
            <Text style={styles.dangerBtnText}>🗑️ Reset All Data</Text>
          </TouchableOpacity>
          <Text style={styles.dangerWarning}>
            Permanently deletes all stacks, habits, streaks, and history.
          </Text>
        </View>

        <Text style={styles.footer}>HabitStacker · Stack habits. Build streaks. Live better.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function formatTime(time: string): string {
  const [h, m] = time.split(':').map(Number);
  const period = h >= 12 ? 'PM' : 'AM';
  const hour = h % 12 === 0 ? 12 : h % 12;
  return `${hour}:${String(m).padStart(2, '0')} ${period}`;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  content: { padding: Spacing.md, paddingBottom: 100 },

  title: { ...Typography.title, color: Colors.text, marginBottom: 4 },
  subtitle: { ...Typography.caption, color: Colors.textSecondary, marginBottom: Spacing.lg },

  section: { marginBottom: Spacing.lg },
  sectionLabel: { ...Typography.label, color: Colors.textMuted, marginBottom: Spacing.sm },

  permissionWarning: {
    backgroundColor: Colors.gold + '15',
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.gold + '40',
    padding: Spacing.md,
    marginBottom: Spacing.sm,
    gap: 6,
  },
  permissionWarningText: { color: Colors.gold, fontSize: 13 },
  permissionLink: { color: Colors.primary, fontSize: 13, fontWeight: '600' },

  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.md,
    gap: Spacing.md,
  },
  settingInfo: { flex: 1 },
  settingTitle: { ...Typography.body, color: Colors.text, fontWeight: '600' },
  settingDesc: { ...Typography.caption, color: Colors.textSecondary, marginTop: 3 },

  toggle: {
    width: 48,
    height: 26,
    borderRadius: 13,
    backgroundColor: Colors.border,
    justifyContent: 'center',
    padding: 3,
  },
  toggleOn: { backgroundColor: Colors.primary },
  toggleThumb: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: Colors.text,
  },
  toggleThumbOn: { alignSelf: 'flex-end' },

  reminderCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
  },
  reminderCardLeft: { flex: 1, gap: 4 },
  reminderStackName: { ...Typography.body, color: Colors.text, fontWeight: '600' },
  activeBadge: {
    alignSelf: 'flex-start',
    backgroundColor: Colors.primary + '25',
    borderRadius: Radius.full,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  activeBadgeText: { color: Colors.primary, fontSize: 10, fontWeight: '700' },
  noBadge: {
    alignSelf: 'flex-start',
    backgroundColor: Colors.border,
    borderRadius: Radius.full,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  noBadgeText: { color: Colors.textMuted, fontSize: 10, fontWeight: '600' },
  reminderCardRight: { alignItems: 'flex-end', gap: 8 },
  reminderTime: { ...Typography.body, color: Colors.text, fontWeight: '500' },
  reminderToggle: {
    width: 36,
    height: 20,
    borderRadius: 10,
    backgroundColor: Colors.border,
    justifyContent: 'center',
    padding: 2,
  },
  reminderToggleOn: { backgroundColor: Colors.primary },

  statsRow: { flexDirection: 'row', gap: Spacing.sm },
  statBox: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.md,
    alignItems: 'center',
    gap: 4,
  },
  statValue: { ...Typography.subtitle, color: Colors.text, fontWeight: '700' },
  statLabel: { ...Typography.caption, color: Colors.textSecondary },

  helpBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.md,
    gap: Spacing.sm,
  },
  helpBtnIcon: { fontSize: 22 },
  helpBtnInfo: { flex: 1 },
  helpBtnTitle: { ...Typography.body, color: Colors.text, fontWeight: '600' },
  helpBtnDesc: { ...Typography.caption, color: Colors.textSecondary, marginTop: 2 },
  helpChevron: { color: Colors.textMuted, fontSize: 20, fontWeight: '300' },

  dangerBtn: {
    backgroundColor: Colors.danger + '15',
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.danger + '40',
    padding: Spacing.md,
    alignItems: 'center',
  },
  dangerBtnText: { color: Colors.danger, fontWeight: '700', fontSize: 14 },
  dangerWarning: { ...Typography.caption, color: Colors.textMuted, textAlign: 'center', marginTop: Spacing.xs },

  footer: {
    ...Typography.caption,
    color: Colors.textMuted,
    textAlign: 'center',
    marginTop: Spacing.lg,
  },
});
